# Horizon on iOS (experimental, untested)

An unofficial iOS port of the Android fork. **It has never been compiled or run.** It was
written on Linux without a Rust toolchain or Apple SDK. Expect compiler errors on the first
`cargo build`; the sections below say where they will come from.

## Layout

| Path | What |
| --- | --- |
| `crates/horizon-ios` | `staticlib` (`libhorizon_ios.a`); sources live in `crates/horizon-client/src/ios_lib.rs` + `ios_main.rs`, like the Android crate |
| `crates/horizon-client/src/ios/*.rs` | iOS replacements for the JNI modules: `platform`, `native_ime`, `documents`, `gallery`, `secure_store`, `updater`, `display`, `app` (stands in for `crate::android`) |
| `crates/horizon-client-render/src/mobile_native.rs` | Replaces the patched `winit::platform::android::native_*` calls (Android keeps using them) |
| `ios/` | `project.yml` (XcodeGen), `Info.plist`, `Sources/main.m` |
| `tools/ios_widen_cfg.py` | The mechanical change below |
| `tools/ios_build.sh`, `tools/ios_engine_data.py` | Rust build for Xcode; engine-table bundling |

## What changed in the engine

Touch controls, mobile rendering policy and memory budgets were gated on
`cfg(target_os = "android")`. `tools/ios_widen_cfg.py` rewrote 375 such sites in
`horizon-client`, `horizon-client-render` and `horizon-client-input` to
`any(target_os = "android", target_os = "ios")`. On Android that expression is identical to
before, so the Android build is unchanged. Everything that really needs the Android runtime
(JNI, `winit::platform::android`) was left Android-only or routed through `mobile_native`.
`horizon-threads` already supports Apple targets and was not touched. The Cargo target
tables now exclude `arboard` and the GLES backend on iOS.

The Android launcher (`android/launcher*.rs`, `catalog.rs`, ...) is pure Rust drawn with
Horizon's own renderer, so it is reused as is: first-run download from Mojang, settings,
world/server selection, then `game::android_game`.

## Build (on a Mac)

```sh
rustup target add aarch64-apple-ios aarch64-apple-ios-sim
python tools/android_prepare.py        # once; your own Minecraft download, JDK 25
python tools/ios_engine_data.py        # -> ios/Resources/engine-data.zip
brew install xcodegen && (cd ios && xcodegen)
open ios/Horizon.xcodeproj             # set your Team, run on a device
```

`tools/ios_build.sh iphoneos|iphonesimulator [--release]` builds the library alone.

## Not implemented (stubs, each logs or returns an error)

* **System keyboard** (`ios/native_ime.rs`, `ios/platform.rs`): chat, signs, server address
  and player name cannot be typed. Plan: `Window::set_ime_allowed` from the event loop and
  `WindowEvent::Ime::Commit` fed through `native_ime::text()`.
* **Clipboard**: in-process only; use `UIPasteboard` (objc2-ui-kit).
* **Account secrets**: `ios/secure_store.rs` refuses to store anything. Never write tokens
  in plaintext; implement the Keychain. Until then Microsoft and Ely.by sign-in fail and
  offline play is the only mode (servers in online mode will reject you).
* **Haptics, open-URL, safe-area insets, render-scale <100%**: no-ops; `display_density()` returns 1.
* **File import/export**: use the Files app (`UIFileSharingEnabled`); the in-app pickers report that.
* **Code mods**: the `mods` feature (wasmtime/cranelift) needs executable memory, which iOS
  forbids; it is off. `.hmod` content packs are not wired up either.
* **Controllers**: `controllers` feature is off (gilrs has no iOS backend).
* **Updater**: none; the store or sideloading tool updates the app.

## Where the first compiler errors will be

1. `game.rs` / `game/android_input.rs`: any remaining `crate::android::*` call that I kept
   Android-only (`first_frame_shown`) is fine, but other mobile-only items may reference
   Android types; add them to `ios/app.rs` or `mobile_native.rs`.
2. `ios/platform.rs` / `ios/documents.rs` signatures versus the callers in `launcher_pages.rs`.
3. `cpal` (audio) needs an `AVAudioSession` category set; without it sound may be silent.
4. wgpu 30 Metal: surface and HDR code paths that assumed Vulkan/GLES on mobile.
5. Memory: iOS terminates apps well below Android's limits. Start with render distance 4-6.

## Distribution

Minecraft is Mojang's; this project ships none of it. The App Store is very unlikely.
Realistic routes are a personal development team (7-day signing), SideStore/AltStore or
TrollStore. Check Mojang's usage guidelines before redistributing anything.
