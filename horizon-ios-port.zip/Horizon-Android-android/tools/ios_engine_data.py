#!/usr/bin/env python3
"""Copy the pinned engine tables (the same engine-data.zip the Android APK embeds) into
ios/Resources/ so Xcode bundles it. Run `python tools/android_prepare.py` once first
(needs your own Minecraft download and a JDK 25 on a PC/Mac)."""
import pathlib, shutil, sys
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import android_build  # reuses engine_data(); nothing is built

source = android_build.engine_data(public=True)
dest = ROOT / "ios" / "Resources"
dest.mkdir(parents=True, exist_ok=True)
shutil.copyfile(source, dest / "engine-data.zip")
print(f"Wrote {dest / 'engine-data.zip'}")
