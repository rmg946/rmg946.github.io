#!/usr/bin/env bash
# Builds libhorizon_ios.a for the SDK Xcode is building (called from the Xcode pre-build phase),
# or by hand: tools/ios_build.sh iphoneos|iphonesimulator [--release]
set -euo pipefail
cd "$(dirname "$0")/.."
SDK="${1:-${PLATFORM_NAME:-iphoneos}}"
PROFILE="${2:-}"
[ -z "$PROFILE" ] && [ "${CONFIGURATION:-Debug}" = "Release" ] && PROFILE="--release"
case "$SDK" in
  iphoneos)        TARGET=aarch64-apple-ios ;;
  iphonesimulator) TARGET=aarch64-apple-ios-sim ;;   # Apple Silicon Macs
  *) echo "unknown SDK $SDK" >&2; exit 2 ;;
esac
export PATH="$HOME/.cargo/bin:$PATH"
rustup target add "$TARGET"
export IPHONEOS_DEPLOYMENT_TARGET=16.0
cargo build -p horizon-ios --target "$TARGET" ${PROFILE:+$PROFILE}
OUT=target/$TARGET/$([ "$PROFILE" = "--release" ] && echo release || echo debug)
mkdir -p "ios/build/$SDK"
cp "$OUT/libhorizon_ios.a" "ios/build/$SDK/libhorizon_ios.a"
