#!/usr/bin/env python3
"""Widen `target_os = "android"` cfgs to Android-or-iOS ("mobile") in engine crates.

Only files that never reference an Android-only API (JNI, winit::platform::android,
android_logger, crate::android::*) are rewritten. Files that do are reported so their
Android-only blocks can be split by hand (see docs/ios-port.md). The Android build is
unchanged: any(android, ios) is true on Android.
Usage: python tools/ios_widen_cfg.py [--dry-run]
"""
import pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent / "crates"
CRATES = ["horizon-client", "horizon-client-render", "horizon-client-input"]  # horizon-threads already handles iOS via target_vendor = "apple"
SKIP_NAMES = {"android_main.rs", "android_lib.rs", "android.rs"}
ANDROID_ONLY = re.compile(
    r"winit::platform::android|jni::|android_activity|android_logger|crate::android::|"
    r"android_dns|ndk::|super::android::")
OLD = 'target_os = "android"'
NEW = 'any(target_os = "android", target_os = "ios")'
dry = "--dry-run" in sys.argv
changed, mixed = [], []
for crate in CRATES:
    for path in sorted((ROOT / crate).rglob("*.rs")):
        rel = path.relative_to(ROOT)
        if "target" in rel.parts or "android" in rel.parts[2:3] or path.name in SKIP_NAMES:
            continue
        text = path.read_text()
        if OLD not in text:
            continue
        hits = [i + 1 for i, l in enumerate(text.splitlines()) if ANDROID_ONLY.search(l)]
        if hits:
            mixed.append((str(rel), text.count(OLD), hits))
            continue
        if not dry:
            path.write_text(text.replace(OLD, NEW))
        changed.append((str(rel), text.count(OLD)))
print(f"rewritten: {len(changed)} files, {sum(c for _, c in changed)} cfg sites")
print(f"mixed (manual): {len(mixed)} files")
for rel, n, hits in mixed:
    print(f"  {rel}: {n} android cfgs; Android-only API at lines {hits[:12]}{'...' if len(hits) > 12 else ''}")
