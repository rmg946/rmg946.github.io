// UIKit's entry point. winit's iOS backend calls UIApplicationMain from inside
// horizon_ios_main (via EventLoop::run_app), so this must not create its own app.
#import <UIKit/UIKit.h>

extern int horizon_ios_main(const char *documents, const char *caches, const char *engine_data);

int main(int argc, char *argv[]) {
    @autoreleasepool {
        NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        NSString *caches = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
        NSString *engine = [[NSBundle mainBundle] pathForResource:@"engine-data" ofType:@"zip"];
        return horizon_ios_main(docs.fileSystemRepresentation,
                                caches.fileSystemRepresentation,
                                engine ? engine.fileSystemRepresentation : NULL);
    }
}
