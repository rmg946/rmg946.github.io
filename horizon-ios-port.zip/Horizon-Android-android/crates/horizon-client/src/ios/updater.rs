//! The Android build self-updates APKs. iOS apps update through the store or the
//! sideloading tool, so this keeps the types `catalog` needs and never checks.
use std::path::PathBuf;
pub const CURRENT_VERSION: &str = env!("CARGO_PKG_VERSION");
pub const REPO: &str = "";
#[derive(Clone, Debug, PartialEq)]
pub struct ReleaseInfo {
    pub version: String,
    pub tag_name: String,
    pub title: String,
    pub changelog: String,
    pub download_url: Option<String>,
    pub asset_name: String,
    pub size_bytes: u64,
}
#[derive(Clone, Debug, PartialEq)]
pub enum UpdateStatus {
    Idle,
    Checking,
    Available(ReleaseInfo),
    Downloading { progress: f32, downloaded: u64, total: u64 },
    Downloaded { path: PathBuf, version: String },
    Error(String),
    Dismissed,
}
pub fn get_status() -> UpdateStatus {
    UpdateStatus::Idle
}
pub fn set_status(_: UpdateStatus) {}
pub fn dismiss() {}
pub fn check_in_background() {}
pub fn check_for_update() -> Result<Option<ReleaseInfo>, String> {
    Ok(None)
}
pub fn download_and_install_in_background(_: ReleaseInfo, _: PathBuf) {}
pub fn trigger_install(_apk_path: &std::path::Path) {}
