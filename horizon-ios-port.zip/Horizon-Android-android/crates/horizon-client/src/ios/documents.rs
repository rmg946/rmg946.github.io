//! Android's Storage Access Framework import/export UI. On iOS the Files app shows the
//! app's Documents/Horizon folder directly (UIFileSharingEnabled), so import and export
//! are "copy files there"; every request below reports that instead of failing silently.
use horizon_client::{
    content_files::Kind,
    hud::{HudAtlas, HudBatch},
    ui_theme::Ui,
};
use std::path::{Path, PathBuf};

type Res<T> = std::result::Result<T, String>;
const MSG: &str = "Import and export use the Files app on iOS: open Files > On My iPhone > Horizon";

#[derive(Clone)]
pub struct Notice {
    pub text: String,
    pub changed: bool,
    pub kind: Option<Kind>,
}
#[derive(Clone, Copy)]
pub enum Choice {
    KeepBoth,
    Replace,
    Cancel,
}
pub fn busy() -> bool {
    false
}
pub fn conflict() -> bool {
    false
}
pub fn poll() -> Option<Notice> {
    None
}
pub fn begin(_kind: Kind, _home: PathBuf) -> Res<()> {
    Err(MSG.into())
}
pub fn picker_failed(_error: &str) {}
pub fn begin_appearance(_home: PathBuf, _kind: crate::skins::library::Kind) -> Res<()> {
    Err(MSG.into())
}
pub fn begin_into_dir(_target_dir: PathBuf) -> Res<()> {
    Err(MSG.into())
}
pub fn begin_folder_into_dir(_target_dir: PathBuf) -> Res<()> {
    Err(MSG.into())
}
pub fn begin_control_import(_game_home: PathBuf) -> Res<()> {
    Err(MSG.into())
}
pub fn begin_control_export(_game_home: PathBuf, _suggested_name: String, _bytes: Vec<u8>) -> Res<()> {
    Err(MSG.into())
}
pub fn begin_file_export(
    _home: PathBuf,
    _source_path: PathBuf,
    _suggested_name: String,
    _mime_type: String,
) -> Res<()> {
    Err(MSG.into())
}
pub fn export_file(_home: &Path, _profile: u32, _file_path: &Path) -> Res<String> {
    Err(MSG.into())
}
pub fn export_folder_prepared(
    _home: &Path,
    _profile: u32,
    _dir_path: &Path,
) -> Res<(PathBuf, String, String)> {
    Err(MSG.into())
}
pub fn export_folder(_home: &Path, _profile: u32, _dir_path: &Path) -> Res<String> {
    Err(MSG.into())
}
pub fn resolve(_choice: Choice) {}
pub fn cancel() {}
pub fn tap(_x: f32, _y: f32) -> bool {
    false
}
pub fn draw(_batch: &mut HudBatch, _atlas: &HudAtlas) {}
pub fn draw_ui(_ui: &mut Ui<'_>) {}
pub fn handle_event(_event: &winit::event::WindowEvent) -> bool {
    false
}
