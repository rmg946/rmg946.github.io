//! iOS system services for the Rust client. Android's version is JNI; here the
//! unimplemented services are explicit no-ops with a TODO, never silent fakes.
use horizon_client::osk::Output;
use std::sync::Mutex;

static CLIPBOARD: Mutex<String> = Mutex::new(String::new());
static CACHE_DIR: std::sync::OnceLock<std::path::PathBuf> = std::sync::OnceLock::new();

pub fn set_cache_dir(path: std::path::PathBuf) {
    let _ = CACHE_DIR.set(path);
}
pub fn cache_dir() -> Option<std::path::PathBuf> {
    CACHE_DIR.get().cloned()
}

// TODO(ios): UIImpactFeedbackGenerator / CoreHaptics.
pub fn vibrate(_pulse: horizon_client::gamepad::Pulse) {}
pub fn cancel_vibration() {}

// TODO(ios): UIPasteboard.general (objc2-ui-kit). In-process only for now.
pub fn clipboard_get() -> Option<String> {
    Some(CLIPBOARD.lock().ok()?.clone()).filter(|s| !s.is_empty())
}
pub fn clipboard_set(text: &str) {
    if let Ok(mut clip) = CLIPBOARD.lock() {
        *clip = text.to_owned();
    }
}
pub fn copy_login_code(text: &str) -> bool {
    clipboard_set(text);
    true
}

pub fn set_orientation(_orientation: crate::catalog::Orientation) {}
pub fn open_repository() -> bool {
    false
}
pub fn open_documents(_id: &str) -> bool {
    false
}
// TODO(ios): UIApplication.openURL; ASWebAuthenticationSession for Microsoft sign-in.
pub fn open_url(_url: &str) -> bool {
    false
}
pub fn open_login_url(_url: &str) -> Result<(), String> {
    Err("Microsoft sign-in is not available on iOS yet; play offline or on a server that allows it".into())
}
pub fn performance_power() -> serde_json::Value {
    serde_json::json!({})
}

pub fn active() -> bool {
    false
}
pub fn finish() {}
pub fn capture_mouse(capture: bool) -> bool {
    crate::native_ime::capture_mouse(capture)
}
pub fn show_secret(_text: &str) {
    log::warn!("iOS system keyboard is not implemented yet");
}
pub fn show(_text: &str) {
    log::warn!("iOS system keyboard is not implemented yet");
}
pub fn show_multiline(_text: &str) {
    log::warn!("iOS system keyboard is not implemented yet");
}
pub fn hide() {}
pub fn poll() -> Vec<Output> {
    vec![]
}

/// Field hit tests use the same GUI coordinates as the touch menus.
pub fn field_at(p: [f32; 2]) -> bool {
    horizon_client::widgets::last_targets().iter().any(|t| {
        let [x, y, w, h] = t.rect;
        t.kind == horizon_client::widgets::Kind::Field
            && (x..x + w).contains(&p[0])
            && (y..y + h).contains(&p[1])
    })
}
pub fn poll_gamepad_connections() {}
pub fn display_density() -> f32 {
    1.0
}
pub fn display_rotation() -> i32 {
    0
}
pub fn apply_high_refresh_rate(_preferred_hz: u16) {}
