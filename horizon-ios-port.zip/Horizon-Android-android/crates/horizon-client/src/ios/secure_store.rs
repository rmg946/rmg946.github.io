//! Account secrets. Android encrypts with Keystore AES-GCM. iOS must use the Keychain
//! (kSecClassGenericPassword, kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly).
//! Until that is written this store REFUSES to save, so no token is ever written in
//! plaintext: Microsoft/Ely.by sign-in is simply unavailable and offline play works.
use crate::account::SecretStore;
pub struct IosStore;
const MSG: &str = "Secure account storage (Keychain) is not implemented on iOS yet";
impl SecretStore for IosStore {
    fn get(&self, _key: &str) -> Result<Option<String>, String> {
        Ok(None)
    }
    fn set(&self, _key: &str, _secret: &str) -> Result<(), String> {
        Err(MSG.into())
    }
    fn delete(&self, _key: &str) -> Result<(), String> {
        Ok(())
    }
    fn persistent(&self) -> bool {
        false
    }
}
