//! Stands in for `android.rs` (the `crate::android` module) in the iOS build.
pub fn first_frame_shown() {}

/// `CFBundleShortVersionString`; the bool is "signed with the official release certificate".
pub fn app_version() -> Option<(String, bool)> {
    Some((env!("CARGO_PKG_VERSION").to_owned(), false))
}

/// iOS cannot relaunch itself; native-mod swaps are not offered here.
pub fn restart_app() {}
