//! Screenshots. Android publishes to MediaStore; iOS keeps them in the app's
//! Documents/Pictures (visible in the Files app). Saving to Photos needs
//! PHPhotoLibrary (not implemented).
use std::{path::Path, sync::Mutex};
static DONE: Mutex<Vec<Result<String, String>>> = Mutex::new(Vec::new());
pub fn save(file: &Path) -> Result<(), String> {
    let dir = crate::backend::data_dir().join("Pictures");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let name = file.file_name().ok_or("Screenshot has no file name")?;
    std::fs::copy(file, dir.join(name)).map_err(|e| e.to_string())?;
    DONE.lock()
        .unwrap_or_else(|e| e.into_inner())
        .push(Ok(format!("Saved to Files > Horizon > Pictures/{}", name.to_string_lossy())));
    Ok(())
}
pub fn poll() -> Vec<Result<String, String>> {
    std::mem::take(&mut *DONE.lock().unwrap_or_else(|e| e.into_inner()))
}
