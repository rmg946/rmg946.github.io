//! Android's system-keyboard bridge. iOS: NOT IMPLEMENTED YET (see docs/ios-port.md).
//! Plan: `winit::window::Window::set_ime_allowed(true)` from the event loop when
//! `show` is requested, and feed `WindowEvent::Ime::Commit` back through `text()`.
pub fn show(_text: &str) -> bool {
    false
}
pub fn show_secret(_text: &str) -> bool {
    false
}
pub fn hide() {}
pub fn text() -> Option<String> {
    None
}
pub fn capture_mouse(_capture: bool) -> bool {
    false
}
/// Height in pixels covered by the keyboard, so the UI can lift above it.
pub fn viewport_bottom() -> Option<u32> {
    None
}
pub fn pick_document() -> bool {
    false
}
pub fn pick_document_tree() -> bool {
    false
}
pub fn create_document(_suggested_name: &str, _mime_type: &str) -> bool {
    false
}
pub fn configure_screen(_immersive: bool, _avoid_cutout: bool) {}
pub fn refresh_bounds() {}
