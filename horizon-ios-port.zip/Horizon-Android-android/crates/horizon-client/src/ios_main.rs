// iOS entry point (generated from android_main.rs by hand; see docs/ios-port.md). The simulation and renderer are shared with desktop.

pub use horizon_client::mod_list;

#[allow(dead_code, clippy::collapsible_match)]
// Shared vanilla match structure and desktop harnesses.
mod game;
#[path = "android/game_launch.rs"]
mod game_launch;
#[path = "android/launcher.rs"]
mod launcher;
// Share the desktop launcher's actual search, compatibility checks, downloads,
// dependency resolution and Java content porting; GPUI itself is desktop-only.
// These files are formatted in the launcher's separate Rust 2021 workspace.
#[rustfmt::skip]
#[allow(dead_code)]
#[path = "../../../launcher/src/account.rs"]
mod account;
#[rustfmt::skip]
#[allow(dead_code)]
#[path = "../../../launcher/src/browser.rs"]
mod browser;
#[path = "ios/app.rs"]
pub(crate) mod android;
#[path = "android/dns.rs"]
mod android_dns;
#[path = "android/catalog.rs"]
mod catalog;
#[path = "android/device_preferences.rs"]
mod device_preferences;
#[path = "android/device_runtime.rs"]
mod device_runtime;
#[path = "android/diagnostics.rs"]
mod diagnostics;
#[path = "ios/display.rs"]
mod display;
#[path = "android/document_store.rs"]
mod document_store;
#[path = "ios/documents.rs"]
mod documents;
#[path = "ios/gallery.rs"]
mod gallery;
#[path = "ios/native_ime.rs"]
mod native_ime;
#[path = "android/performance.rs"]
mod performance;
#[path = "ios/platform.rs"]
mod platform;
#[rustfmt::skip]
#[allow(dead_code)]
#[path = "../../../launcher/src/proxy.rs"]
mod proxy;
#[path = "android/search_queue.rs"]
mod search_queue;
#[path = "ios/secure_store.rs"]
mod secure_store;
#[path = "android/shader_catalog.rs"]
mod shader_catalog;
#[path = "ios/updater.rs"]
mod updater;
#[rustfmt::skip]
#[allow(dead_code)]
#[path = "../../../launcher/src/skins.rs"]
mod skins;
// The shared account protocol needs only the launcher's version and data path.
mod backend {
    pub const VERSION: &str = "1.0.1";
    static HOME: std::sync::OnceLock<std::path::PathBuf> = std::sync::OnceLock::new();
    pub fn initialize(home: std::path::PathBuf) {
        let _ = HOME.set(home);
    }
    pub fn game_home() -> std::path::PathBuf {
        data_dir()
    }
    pub fn game_mod_api_level() -> Option<u32> {
        Some(horizon_mods::api_level::LEVEL)
    }
    pub fn data_dir() -> std::path::PathBuf {
        HOME.get().expect("horizon_ios_main sets the data directory").clone()
    }
}

pub(crate) fn keyboard_mouse_input() -> bool {
    horizon_client::android_runtime::active_input() == catalog::InputHost::KeyboardMouse
}
pub(crate) fn configure_input_mode(mode: catalog::InputHost) {
    horizon_client::android_runtime::configure_input(mode);
}
pub(crate) fn touch_visible() -> bool {
    horizon_client::android_runtime::active_input() == catalog::InputHost::Touch
}
pub(crate) fn touch_input(touch: bool) {
    horizon_client::android_runtime::note_input(if touch {
        catalog::InputHost::Touch
    } else {
        catalog::InputHost::KeyboardMouse
    });
}
pub(crate) fn save_input_mode() {
    let home = backend::data_dir();
    let mut config = catalog::Config::load(&home);
    let mode = horizon_client::android_runtime::input_mode();
    if config.input_host != mode {
        config.input_host = mode;
        if let Err(e) = config.save(&home) {
            log::warn!("Saving input mode: {e}");
        }
    }
}
pub(crate) const PUBLIC_BUILD: bool = match option_env!("HORIZON_IOS_PUBLIC") {
    Some(value) => value.len() == 1 && value.as_bytes()[0] == b'1',
    None => false,
};


use std::ffi::{CStr, c_char};
use winit::event_loop::EventLoop;

/// `game.rs` calls this where Android supplies its NativeActivity loop. winit's iOS
/// backend owns UIApplicationMain, so it is the plain loop.
pub(crate) fn android_event_loop() -> Result<EventLoop<()>, winit::error::EventLoopError> {
    EventLoop::new()
}

struct IosLogger;
impl log::Log for IosLogger {
    fn enabled(&self, metadata: &log::Metadata<'_>) -> bool {
        metadata.level() <= log::Level::Info
    }
    fn log(&self, record: &log::Record<'_>) {
        if self.enabled(record.metadata()) {
            // stderr appears in the Xcode console and Console.app.
            eprintln!("[Horizon {}] {}: {}", record.level(), record.target(), record.args());
            diagnostics::log_line(record.level(), record.target(), &record.args().to_string());
        }
    }
    fn flush(&self) {
        diagnostics::request_flush();
    }
}

fn init_logging() {
    static LOGGER: IosLogger = IosLogger;
    if log::set_logger(&LOGGER).is_ok() {
        log::set_max_level(log::LevelFilter::Info);
    }
}

fn path_arg(ptr: *const c_char) -> Option<std::path::PathBuf> {
    if ptr.is_null() {
        return None;
    }
    // SAFETY: the caller (main.m) passes NUL-terminated UTF-8 strings that outlive the call.
    let text = unsafe { CStr::from_ptr(ptr) }.to_str().ok()?;
    Some(std::path::PathBuf::from(text))
}

/// Called from `ios/Sources/main.m`. Never returns while the app runs: winit's iOS
/// backend calls UIApplicationMain from `run_app`.
///
/// * `documents`   - NSDocumentDirectory (shown in the Files app).
/// * `caches`      - NSCachesDirectory.
/// * `engine_data` - the bundled `engine-data.zip`, or NULL.
#[unsafe(no_mangle)]
pub extern "C" fn horizon_ios_main(
    documents: *const c_char,
    caches: *const c_char,
    engine_data: *const c_char,
) -> i32 {
    horizon_client::mod_api::install_runtime_hooks(Default::default());
    init_logging();
    let (Some(documents), Some(caches)) = (path_arg(documents), path_arg(caches)) else {
        eprintln!("Horizon: main.m passed no data directory");
        return 1;
    };
    let home = documents.join("Horizon");
    if let Err(error) = std::fs::create_dir_all(&home).and_then(|()| std::env::set_current_dir(&home)) {
        log::error!("Cannot open {}: {error}", home.display());
        return 1;
    }
    backend::initialize(home.clone());
    horizon_client::logging::set_private_home(home.clone());
    if let Err(error) = diagnostics::initialize(&home, serde_json::json!({})) {
        log::error!("Cannot initialize local diagnostics: {error}");
    }
    platform::set_cache_dir(caches.clone());
    horizon_client::android_runtime::configure_cache_dir(caches.clone());
    horizon_client::official_install::configure_download_cache_dir(caches);
    horizon_client::android_runtime::install_clipboard(horizon_client::android_runtime::ClipboardHooks {
        get: platform::clipboard_get,
        set: platform::clipboard_set,
    });
    horizon_client::crash::install(home.clone(), "client");
    if let Some(source) = path_arg(engine_data) {
        // Same contract as Android's APK asset: the pinned engine tables, copied once.
        let target = home.join("engine-data.zip");
        let copied = std::fs::File::open(&source).and_then(|mut input| {
            let mut out = std::fs::File::create(home.join("engine-data.partial"))?;
            std::io::copy(&mut input, &mut out)?;
            drop(out);
            std::fs::rename(home.join("engine-data.partial"), &target)
        });
        if let Err(error) = copied {
            log::error!("Cannot unpack engine data: {error}");
        }
    }
    let mut launcher = launcher::Launcher::new(home.clone());
    let result = android_event_loop()
        .map_err(|e| -> Box<dyn std::error::Error> { e.into() })
        .and_then(|events| events.run_app(&mut launcher).map_err(Into::into));
    if let Err(error) = result {
        log::error!("Horizon: {error}");
        diagnostics::record_error(&error.to_string());
        horizon_client::crash::report_error(&home, "client", &*error);
        return 1;
    }
    0
}
