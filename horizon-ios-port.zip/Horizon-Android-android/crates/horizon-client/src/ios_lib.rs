//! The `libhorizon_ios.a` staticlib entry: the thin glue between `ios/Sources/main.m`
//! (UIKit's `main`) and `horizon-client`. Mirrors `android_lib.rs`.
#![cfg(target_os = "ios")]

include!("ios_main.rs");
