//! Shader packs: the one picked on Options > Horizon Settings > Shader Packs, or
//! `HORIZON_SHADER_PACK=<name>` (development; it wins over the pick), runs `shaderpacks/<name>`
//! (a folder or a zip beside `options.txt`) over the world; Horizon's own packs go to
//! `game/native_shaders.rs`. The programs of the current dimension's folder are loaded when the
//! dimension changes (spec 1.2).

use horizon_client::camera::CameraFluid;
use horizon_client::gfx::pack_uniforms::{PackInputs, PlayerStatus};
use horizon_client::shader_options::ShaderOptions;
use horizon_client::text::Text;
use horizon_shaders::{BlockIds, Macros, Pack, Properties, dimension_folder, load_post};

use super::{Dim, Game};
use horizon_client::gfx::pack_draw::EntitySpan;
use std::cell::RefCell;
use std::collections::{BTreeMap, HashMap};

/// The values the player chose for pack `name`'s options (`shaderpacks/<name>.txt`).
fn chosen_shader_options(name: &str) -> BTreeMap<String, String> {
    let file = Game::shader_packs_dir().join(horizon_shaders::chosen_file(name));
    std::fs::read_to_string(file)
        .map(|text| horizon_shaders::parse_chosen(&text))
        .unwrap_or_default()
}

/// Pack `name`'s options, screens and names in `language`, with the values the player chose.
pub(super) fn read_shader_options(
    name: &str,
    language: &str,
    macros: &Macros,
) -> Option<ShaderOptions> {
    let pack = match Pack::open(&Game::shader_packs_dir().join(name)) {
        Ok(pack) => pack,
        Err(e) => {
            log::warn!("shader pack {name}: {e}");
            return None;
        }
    };
    let options = horizon_shaders::options(&pack);
    let lang = horizon_shaders::Lang::load(&pack, language);
    let chosen = chosen_shader_options(name);
    let pack = pack.with_chosen(chosen.clone());
    let text = pack.read_text("shaders.properties").unwrap_or_default();
    let properties = Properties::parse(&text, &horizon_shaders::with_options(&pack, macros));
    let screens = horizon_shaders::Screens::parse(&properties, &options);
    Some(ShaderOptions::new(
        name.to_owned(),
        options,
        screens,
        lang,
        chosen,
    ))
}

/// Saves the values chosen on the Shader Options page; none chosen removes the file.
pub(super) fn write_shader_options(options: &ShaderOptions) {
    let file = Game::shader_packs_dir().join(horizon_shaders::chosen_file(&options.pack));
    let saved = if options.chosen.is_empty() {
        std::fs::remove_file(&file).or_else(|e| match e.kind() {
            std::io::ErrorKind::NotFound => Ok(()),
            _ => Err(e),
        })
    } else {
        std::fs::write(&file, horizon_shaders::chosen_text(&options.chosen))
    };
    if let Err(e) = saved {
        log::warn!("shader pack {}: {}: {e}", options.pack, file.display());
    }
}

// A native mod can bundle a pack as `native-<mod-id>`; its Mods toggle controls it too.
fn active_pack<'a>(picked: &'a str, mods: &horizon_client::mod_list::ModList) -> &'a str {
    if picked.strip_prefix("native-").is_some_and(|id| {
        mods.installed
            .iter()
            .any(|m| m.id == id && m.native.is_some() && mods.disabled.contains(id))
    }) {
        ""
    } else {
        picked
    }
}

/// Whether the pack `settings` pick (or `HORIZON_SHADER_PACK`) is one of Horizon's own: only
/// then do resource loads read the resource packs' LabPBR maps (`sprites::set_labpbr_maps`).
pub(super) fn picks_native_pack(settings: &horizon_client::settings::Settings) -> bool {
    let dev = std::env::var("HORIZON_SHADER_PACK").ok();
    let picked = active_pack(
        dev.as_deref().unwrap_or(&settings.horizon.shader_pack),
        &settings.mods,
    );
    !picked.is_empty()
        && horizon_shader_api::package::is_pack(&Game::shader_packs_dir().join(picked))
}

/// The ids a pack gives entities and block entities (4.1, 5.3), for the spans of the entity
/// geometry.
pub(super) struct PackIds {
    entities: HashMap<String, i32>,
    blocks: BlockIds,
    /// `blockEntityId` by block state, filled as states are drawn.
    block_states: RefCell<HashMap<u32, i32>>,
    /// The id of a name the file lacks: 65535, or 0 without the file.
    missing_entity: i32,
    missing_block: i32,
    /// `item.properties` (4.1) and the id of a held item the file lacks, or of an empty hand:
    /// −1, or 0 without the file (5.3).
    items: HashMap<String, i32>,
    missing_item: i32,
    /// `oldHandLight` (3.2): the first held item and light are those of the brighter hand.
    old_hand_light: bool,
    /// `oldLighting`: `true` keeps the game's face shading in the block colours.
    old_lighting: bool,
}

struct PreparedShaderPack {
    folder: String,
    post: horizon_shaders::Post,
    ids: BlockIds,
    items: HashMap<String, i32>,
    missing_item: i32,
    old_hand_light: bool,
    old_lighting: bool,
    entities: HashMap<String, i32>,
    missing_entity: i32,
    missing_block: i32,
}

type ShaderWorkerResult =
    std::result::Result<std::result::Result<PreparedShaderPack, String>, String>;

struct BuiltShaderPack {
    folder: String,
    built: horizon_client::gfx::PackPost,
    ids: BlockIds,
    items: HashMap<String, i32>,
    missing_item: i32,
    old_hand_light: bool,
    old_lighting: bool,
    entities: HashMap<String, i32>,
    missing_entity: i32,
    missing_block: i32,
}

type ShaderGpuWorkerResult = std::result::Result<BuiltShaderPack, String>;

enum ShaderJobStage {
    Cpu(std::sync::mpsc::Receiver<ShaderWorkerResult>),
    Gpu(std::sync::mpsc::Receiver<ShaderGpuWorkerResult>),
}

struct PendingShaderJob {
    name: String,
    dimension: i32,
    started: std::time::Instant,
    stage: ShaderJobStage,
}

static PENDING_SHADER_JOB: std::sync::Mutex<Option<PendingShaderJob>> = std::sync::Mutex::new(None);
static SHADER_JOB_GENERATION: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
static SHADER_GPU_BUILD_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

pub fn pending_shader_pack_status() -> Option<String> {
    let slot = PENDING_SHADER_JOB.lock().ok()?;
    let job = slot.as_ref()?;
    let stage = match job.stage {
        ShaderJobStage::Cpu(_) => "translating",
        ShaderJobStage::Gpu(_) => "building pipelines",
    };
    Some(format!(
        "Compiling Shader Pack: {} ({}, {:.1}s)...",
        job.name,
        stage,
        job.started.elapsed().as_secs_f32()
    ))
}

fn clear_pending_shader_job() {
    SHADER_JOB_GENERATION.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
    if let Ok(mut slot) = PENDING_SHADER_JOB.lock() {
        *slot = None;
    }
}

fn compile_shader_pack_cpu(
    path: &std::path::Path,
    name: &str,
    dimension: i32,
    mut macros: Macros,
    inputs: horizon_shaders::GameInputs,
    biome_names: &[String],
) -> std::result::Result<PreparedShaderPack, String> {
    let pack = Pack::open(path)
        .map(|p| p.with_chosen(chosen_shader_options(name)))
        .map_err(|e| e.to_string())?;
    let text = pack.read_text("shaders.properties").unwrap_or_default();
    let properties = Properties::parse(&text, &horizon_shaders::with_options(&pack, &macros));
    for note in macros.define_features(&properties) {
        log::warn!("shader pack {name}: {note}");
    }
    for note in &properties.notes {
        log::warn!(
            "shader pack {name}: shaders.properties:{}: {}",
            note.line,
            note.message
        );
    }
    let folder = dimension_folder(&pack, dimension);
    let mut post = load_post(&pack, &folder, &properties, &macros, &inputs);
    let biome_refs: Vec<&str> = biome_names.iter().map(String::as_str).collect();
    post.custom.set_biomes(&biome_refs);
    let text = pack.read_text("block.properties").unwrap_or_default();
    let ids = BlockIds::parse(&Properties::parse(&text, &macros));
    for note in &ids.notes {
        log::warn!("shader pack {name}: block.properties: {note}");
    }
    let text = pack.read_text("entity.properties");
    let entities = BlockIds::parse_kind(
        &Properties::parse(text.as_deref().unwrap_or_default(), &macros),
        "entity",
    );
    let text_item = pack.read_text("item.properties");
    let items = BlockIds::parse_kind(
        &Properties::parse(text_item.as_deref().unwrap_or_default(), &macros),
        "item",
    );
    Ok(PreparedShaderPack {
        folder,
        post,
        missing_item: if text_item.is_some() { -1 } else { 0 },
        old_hand_light: properties
            .get("oldHandLight")
            .is_none_or(|v| v.trim() != "false"),
        old_lighting: properties
            .get("oldLighting")
            .is_some_and(|v| v.trim() == "true"),
        entities: entities.plain(),
        missing_entity: if text.is_some() { 65535 } else { 0 },
        missing_block: if ids.is_empty() { 0 } else { 65535 },
        items: items.plain(),
        ids,
    })
}

impl Game<'_> {
    fn apply_prepared_shader_pack(
        &mut self,
        name: &str,
        dimension: i32,
        started: std::time::Instant,
        loaded: ShaderWorkerResult,
    ) {
        match loaded {
            Ok(Ok(prepared)) => {
                let started_ids = std::time::Instant::now();
                let table = block_id_table(&self.pack, &prepared.ids);
                log::info!(
                    "shader pack {name}: mc_Entity for {} of {} block sprites in {} ms",
                    table.chunks(2).filter(|p| p[0] != -1).count(),
                    table.len() / 2,
                    started_ids.elapsed().as_millis()
                );
                let mut active = false;
                if let Some(renderer) = &mut self.renderer {
                    if let Some((programs, notes)) =
                        renderer.set_shader_pack(dimension, Some(prepared.post), &table)
                    {
                        for note in notes {
                            log::warn!("shader pack {name}: {note}");
                        }
                        log::info!(
                            "shader pack {name}: folder `{}`, {} programs ({}) in {} ms",
                            prepared.folder,
                            programs.len(),
                            programs.join(" "),
                            started.elapsed().as_millis()
                        );
                    }
                    active = renderer.has_active_shader_pack();
                }
                if active {
                    self.pack_ids = Some(PackIds {
                        items: prepared.items,
                        missing_item: prepared.missing_item,
                        old_hand_light: prepared.old_hand_light,
                        old_lighting: prepared.old_lighting,
                        entities: prepared.entities,
                        missing_entity: prepared.missing_entity,
                        missing_block: prepared.missing_block,
                        blocks: prepared.ids,
                        block_states: RefCell::default(),
                    });
                } else {
                    self.pack_ids = None;
                }
            }
            Ok(Err(e)) => {
                self.pack_ids = None;
                log::warn!("shader pack {name}: {e}");
                if let Some(renderer) = &mut self.renderer {
                    renderer.set_shader_pack(dimension, None, &[]);
                }
            }
            Err(panic) => {
                self.shader_pack_failed(name, dimension, &panic);
            }
        }
    }

    /// Loads the pack for the current dimension when it changed, and returns this frame's
    /// inputs to the pack's uniforms.
    pub(super) fn shader_pack_inputs(&mut self, camera: glam::DVec3, partial: f32) -> PackInputs {
        // A `shaders/` pack lights the faces itself unless `oldLighting=true`: sections mesh
        // without the game's face shading (the pack loaded or dropped below shows next frame).
        let pack_lighting = self.pack_ids.as_ref().is_some_and(|ids| !ids.old_lighting);
        if self.streaming.shader_pack_lighting != pack_lighting {
            self.streaming.shader_pack_lighting = pack_lighting;
            self.all_sections_changed();
        }
        static DEV_PACK: std::sync::OnceLock<Option<String>> = std::sync::OnceLock::new();
        let dev = DEV_PACK.get_or_init(|| std::env::var("HORIZON_SHADER_PACK").ok());
        let picked = active_pack(
            dev.as_deref().unwrap_or(&self.settings.horizon.shader_pack),
            &self.settings.mods,
        );
        if self.native_shaders.picked != picked {
            // Another pack, or none: drop what ran.
            self.native_shaders = super::native_shaders::NativeShaders::picking(picked);
            self.pack_ids = None;
            clear_pending_shader_job();
            if let Some(renderer) = &mut self.renderer {
                renderer.drop_shader_packs();
            }
        }
        if picked.is_empty() {
            return PackInputs::default();
        }
        let name = picked.to_owned();
        let dimension = match self.dim {
            Dim::Overworld => 0,
            Dim::Nether => -1,
            Dim::End => 1,
        };
        let mut path = Self::shader_packs_dir().join(&name);
        if !path.exists() {
            if let Some(bytes) = horizon_shader_api::build_builtin_hshader_bytes(&name) {
                let clean = name
                    .strip_prefix("horizon:")
                    .unwrap_or(&name)
                    .strip_suffix(".hshader")
                    .unwrap_or(&name);
                let dir = Self::shader_packs_dir();
                let _ = std::fs::create_dir_all(&dir);
                let target = dir.join(format!("{clean}.hshader"));
                if std::fs::write(&target, bytes).is_ok() {
                    path = target;
                }
            }
        }
        if horizon_shader_api::package::is_pack(&path) {
            // One of Horizon's own packs (game/native_shaders.rs).
            self.tick_native_shader_pack(&path);
        } else if self
            .renderer
            .as_ref()
            .is_some_and(|r| r.shader_pack_dimension() != Some(dimension))
        {
            if cfg!(any(any(target_os = "android", target_os = "ios"), target_os = "ios")) {
                let mut cpu_finished = None;
                let mut gpu_finished = None;
                {
                    let mut slot = PENDING_SHADER_JOB.lock().unwrap();
                    let matches_job = slot
                        .as_ref()
                        .is_some_and(|j| j.name == name && j.dimension == dimension);
                    if !matches_job {
                        let renderer = self.renderer.as_mut().unwrap();
                        let mut macros = Macros::standard();
                        renderer.define_pack_macros(&mut macros);
                        let inputs = renderer.pack_inputs();
                        let biomes = world_biomes!(self);
                        let biome_names: Vec<String> =
                            biomes.list.iter().map(|b| b.name.clone()).collect();
                        let (tx, rx) = std::sync::mpsc::channel();
                        let job_path = path.clone();
                        let job_name = name.clone();
                        let started = std::time::Instant::now();
                        let _ = std::thread::Builder::new()
                            .name("shader-pack-loader".into())
                            .spawn(move || {
                                let res = horizon_client::crash::contain(|| {
                                    compile_shader_pack_cpu(
                                        &job_path,
                                        &job_name,
                                        dimension,
                                        macros,
                                        inputs,
                                        &biome_names,
                                    )
                                });
                                let _ = tx.send(res);
                            });
                        *slot = Some(PendingShaderJob {
                            name: name.clone(),
                            dimension,
                            started,
                            stage: ShaderJobStage::Cpu(rx),
                        });
                    }
                    if let Some(job) = slot.as_ref() {
                        match &job.stage {
                            ShaderJobStage::Cpu(rx) => match rx.try_recv() {
                                Ok(res) => {
                                    let job = slot.take().unwrap();
                                    cpu_finished = Some((job.started, res));
                                }
                                Err(std::sync::mpsc::TryRecvError::Empty) => {}
                                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                                    let job = slot.take().unwrap();
                                    cpu_finished = Some((
                                        job.started,
                                        Err("shader loader thread disconnected".into()),
                                    ));
                                }
                            },
                            ShaderJobStage::Gpu(rx) => match rx.try_recv() {
                                Ok(res) => {
                                    let job = slot.take().unwrap();
                                    gpu_finished = Some((job.started, res));
                                }
                                Err(std::sync::mpsc::TryRecvError::Empty) => {}
                                Err(std::sync::mpsc::TryRecvError::Disconnected) => {
                                    let job = slot.take().unwrap();
                                    gpu_finished = Some((
                                        job.started,
                                        Err("shader GPU builder thread disconnected".into()),
                                    ));
                                }
                            },
                        }
                    }
                }
                if let Some((started, loaded)) = cpu_finished {
                    match loaded {
                        Ok(Ok(prepared)) => {
                            let started_ids = std::time::Instant::now();
                            let table = block_id_table(&self.pack, &prepared.ids);
                            log::info!(
                                "shader pack {name}: mc_Entity for {} of {} block sprites in {} ms",
                                table.chunks(2).filter(|p| p[0] != -1).count(),
                                table.len() / 2,
                                started_ids.elapsed().as_millis()
                            );
                            if let Some(renderer) = &self.renderer {
                                let ctx = renderer.shader_pack_build_context();
                                let job_gen = SHADER_JOB_GENERATION
                                    .fetch_add(1, std::sync::atomic::Ordering::SeqCst)
                                    + 1;
                                let (tx, rx) = std::sync::mpsc::channel();
                                let _ = std::thread::Builder::new()
                                    .name("shader-pack-gpu".into())
                                    .spawn(move || {
                                        let _build_guard = SHADER_GPU_BUILD_LOCK
                                            .lock()
                                            .unwrap_or_else(std::sync::PoisonError::into_inner);
                                        if SHADER_JOB_GENERATION
                                            .load(std::sync::atomic::Ordering::SeqCst)
                                            != job_gen
                                        {
                                            return;
                                        }
                                        let res = horizon_client::crash::contain(move || {
                                            let built = ctx.build(prepared.post, &table);
                                            BuiltShaderPack {
                                                folder: prepared.folder,
                                                built,
                                                ids: prepared.ids,
                                                items: prepared.items,
                                                missing_item: prepared.missing_item,
                                                old_hand_light: prepared.old_hand_light,
                                                old_lighting: prepared.old_lighting,
                                                entities: prepared.entities,
                                                missing_entity: prepared.missing_entity,
                                                missing_block: prepared.missing_block,
                                            }
                                        });
                                        let _ = tx.send(res);
                                    });
                                let mut slot = PENDING_SHADER_JOB.lock().unwrap();
                                *slot = Some(PendingShaderJob {
                                    name: name.clone(),
                                    dimension,
                                    started,
                                    stage: ShaderJobStage::Gpu(rx),
                                });
                            }
                        }
                        other => self.apply_prepared_shader_pack(&name, dimension, started, other),
                    }
                }
                if let Some((started, gpu_res)) = gpu_finished {
                    match gpu_res {
                        Ok(built_pack) => {
                            let mut active = false;
                            if let Some(renderer) = &mut self.renderer {
                                if let Some((programs, notes)) = renderer
                                    .install_built_shader_pack(dimension, Some(built_pack.built))
                                {
                                    for note in notes {
                                        log::warn!("shader pack {name}: {note}");
                                    }
                                    log::info!(
                                        "shader pack {name}: folder `{}`, {} programs ({}) in {} ms",
                                        built_pack.folder,
                                        programs.len(),
                                        programs.join(" "),
                                        started.elapsed().as_millis()
                                    );
                                }
                                active = renderer.has_active_shader_pack();
                            }
                            if active {
                                self.pack_ids = Some(PackIds {
                                    items: built_pack.items,
                                    missing_item: built_pack.missing_item,
                                    old_hand_light: built_pack.old_hand_light,
                                    old_lighting: built_pack.old_lighting,
                                    entities: built_pack.entities,
                                    missing_entity: built_pack.missing_entity,
                                    missing_block: built_pack.missing_block,
                                    blocks: built_pack.ids,
                                    block_states: RefCell::default(),
                                });
                            } else {
                                self.pack_ids = None;
                            }
                        }
                        Err(panic) => self.shader_pack_failed(&name, dimension, &panic),
                    }
                }
            } else {
                let started = std::time::Instant::now();
                let (macros, inputs) = {
                    let renderer = self.renderer.as_mut().unwrap();
                    let mut macros = Macros::standard();
                    renderer.define_pack_macros(&mut macros);
                    (macros, renderer.pack_inputs())
                };
                let biomes = world_biomes!(self);
                let biome_names: Vec<String> = biomes.list.iter().map(|b| b.name.clone()).collect();
                let loaded = horizon_client::crash::contain(|| {
                    compile_shader_pack_cpu(&path, &name, dimension, macros, inputs, &biome_names)
                });
                self.apply_prepared_shader_pack(&name, dimension, started, loaded);
            }
        }
        let lerp = |(old, new): (f32, f32)| old + (new - old) * partial;
        let at = camera.floor().as_ivec3();
        let light = self.world.light(at.x, at.y, at.z);
        let biome = self
            .world
            .chunks
            .get(&(at.x >> 4, at.z >> 4))
            .map(|c| c.biome(at.x, at.y, at.z));
        let (held_items, held_light) = self.held_for_pack();
        let info = biome.map(|b| world_biomes!(self).get(b));
        PackInputs {
            day_time: self.world.day_time,
            rain: lerp(self.world.weather.rain_level),
            thunder: lerp(self.world.weather.thunder_level),
            eye_in: match self.camera_fluid(camera.to_array()) {
                CameraFluid::None => 0,
                CameraFluid::Water => 1,
                CameraFluid::Lava => 2,
                CameraFluid::PowderSnow => 3,
            },
            blindness: f32::from(u8::from(self.potions.effects.get("blindness").is_some())),
            eye_light: [i32::from(light & 15), i32::from(light >> 4)],
            hide_gui: self.ui.hide_gui,
            brightness: self.settings.gamma,
            biome: biome.map_or(-1, i32::from),
            biome_known: biome.is_some(),
            biome_category: info.map_or(0, |b| horizon_shaders::biome_category(&b.name)),
            biome_precipitation: info.map_or(0, |b| {
                horizon_shaders::biome_precipitation(b.precipitation, b.temperature)
            }),
            temperature: info.map_or(0.0, |b| b.temperature),
            rainfall: info.map_or(0.0, |b| b.downfall),
            held_items,
            held_light,
            mod_params: self.native_shader_params_now(partial),
            status: self.pack_player_status(),
        }
    }

    fn pack_player_status(&mut self) -> PlayerStatus {
        let spectator = self.spectator();
        let survival = !self.creative && !spectator;
        let invisible = self.own_invisible();
        let riding = self.riding.is_some();
        let Some(p) = &mut self.player else {
            return PlayerStatus::default();
        };
        let max_health = p.attribute("minecraft:max_health").unwrap_or(20.0) as f32;
        let health = if survival {
            p.health.health().max(1.0)
        } else {
            max_health.max(20.0)
        };
        PlayerStatus {
            survival,
            health,
            max_health: max_health.max(20.0),
            food: p.health.food.food as f32,
            air: p.air as f32,
            armor: p
                .attribute("minecraft:armor")
                .or_else(|_| p.attribute("armor"))
                .unwrap_or(0.0) as f32,
            spectator,
            riding,
            feet_in_water: p.fluids.was_touching_water,
            swimming: p.pose == horizon_client::pose::Pose::Swimming,
            burning: p.fire_ticks > 0 && !spectator,
            hurt: p.health.hurt_animation_time > 0,
            invisible,
            sneaking: p.pose == horizon_client::pose::Pose::Crouching,
            sprinting: p.sprinting,
            elytra_flying: p.fall_flying,
        }
    }

    /// The Shader Options page opened: the picked pack's options, screens and names.
    pub(super) fn open_shader_options(&mut self) {
        let mut macros = Macros::standard();
        if let Some(renderer) = &self.renderer {
            renderer.define_pack_macros(&mut macros);
        }
        let name = &self.settings.horizon.shader_pack;
        self.settings.shader_options = read_shader_options(name, &self.settings.language, &macros);
    }

    /// The Shader Options page closed with changes: they are saved, and the pack loads again.
    pub(super) fn save_shader_options(&mut self) {
        let Some(options) = self.settings.shader_options.take() else {
            return;
        };
        write_shader_options(&options);
        self.pack_ids = None;
        clear_pending_shader_job();
        if let Some(renderer) = &mut self.renderer {
            renderer.drop_shader_packs();
        }
    }

    /// Turns off the pack `name` after loading it panicked: nothing runs in its place, it is no
    /// longer the picked pack (so the next start does not load it again), and the chat says so.
    fn shader_pack_failed(&mut self, name: &str, dimension: i32, error: &str) {
        log::error!("shader pack {name}: fallback for dimension {dimension} (kept enabled in settings): {error}");
        self.pack_ids = None;
        if let Some(renderer) = &mut self.renderer {
            // Marks this dimension as loaded, without a pack, so it does not loop-crash this dimension,
            // while preserving self.settings.horizon.shader_pack so the user's chosen shader does not turn off automatically.
            renderer.set_shader_pack(dimension, None, &[]);
        }
        self.system_message(Text::colored(
            format!("Shader pack {name} could not be loaded and was turned off"),
            0xFF5555,
        ));
    }

    /// `heldItemId(2)` and `heldBlockLightValue(2)`: main hand, then off hand (5.2, 5.3).
    fn held_for_pack(&mut self) -> ([i32; 2], [i32; 2]) {
        if self.pack_ids.is_none() {
            return ([0; 2], [0; 2]);
        }
        if self.luminance.is_none() {
            self.luminance = Some(horizon_client::dynamic_light::Luminance::new(
                self.res.facts(),
                self.pack.assets.registry,
            ));
        }
        let (Some(ids), Some(lum)) = (&self.pack_ids, &self.luminance) else {
            return ([0; 2], [0; 2]);
        };
        let hands = [self.selected, super::shield::OFFHAND_SLOT].map(|slot| {
            let item = self.stack_in(slot).map(|s| &*s.item);
            let id = item.and_then(|i| ids.items.get(i).copied());
            (
                id.unwrap_or(ids.missing_item),
                item.map_or(0, |i| i32::from(lum.of(i))),
            )
        });
        let first = if ids.old_hand_light && hands[1].1 > hands[0].1 {
            hands[1]
        } else {
            hands[0]
        };
        ([first.0, hands[1].0], [first.1, hands[1].1])
    }
}

impl Game<'_> {
    /// Starts a span of the entity geometry at vertex `start` for entity type `name`
    /// (`minecraft:zombie`; "" for one the pack cannot name). Nothing without a pack.
    pub(super) fn mark_entity(&self, start: usize, name: &str) {
        self.mark_entity_part(start, name, false);
    }

    /// Starts a span for entity geometry that blends (name tags, shadows).
    pub(super) fn mark_translucent_entity(&self, start: usize, name: &str) {
        self.mark_entity_part(start, name, true);
    }

    fn mark_entity_part(&self, start: usize, name: &str, translucent: bool) {
        let id = match &self.pack_ids {
            Some(ids) => ids
                .entities
                .get(name)
                .copied()
                .unwrap_or(ids.missing_entity),
            None if native_spans() => name_id(name),
            None => return,
        };
        self.push_span(start, "ENTITIES", id);
        if let Some(last) = self.entity_spans.borrow_mut().last_mut() {
            last.translucent = translucent;
        }
    }

    /// Starts a span for the block entity of block state `state`.
    pub(super) fn mark_block_entity(&self, start: usize, state: u32) {
        let Some(ids) = &self.pack_ids else {
            if native_spans() {
                self.push_span(start, "BLOCK_ENTITIES", state as i32);
            }
            return;
        };
        let id = *ids
            .block_states
            .borrow_mut()
            .entry(state)
            .or_insert_with(|| {
                let registry = self.pack.assets.registry;
                registry
                    .state(horizon_world::registry::BlockStateId(state))
                    .and_then(|s| {
                        ids.blocks
                            .id(&s.name, |k| s.properties.get(k).map(String::as_str))
                    })
                    .unwrap_or(ids.missing_block)
            });
        self.push_span(start, "BLOCK_ENTITIES", id);
        let emission = self
            .res
            .facts()
            .get(horizon_world::registry::BlockStateId(state))
            .emission;
        if let Some(last) = self.entity_spans.borrow_mut().last_mut() {
            last.emissive = emission > 0;
        }
    }

    /// Starts the span of the local player's model; `hidden` in first person, where only a
    /// pack's shadow pass draws it.
    pub(super) fn mark_player(&self, start: usize, hidden: bool) {
        self.mark_entity(start, "minecraft:player");
        if (self.pack_ids.is_some() || native_spans())
            && let Some(last) = self.entity_spans.borrow_mut().last_mut()
        {
            last.player = true;
            last.hidden = hidden;
        }
    }

    /// Marks vertices `start..end` (one entity) as hidden from the camera, for an entity
    /// Horizon's culling would drop but a pack's shadow pass still draws (`EntitySpan::hide`).
    pub(super) fn hide_spans_from(&self, start: usize, end: usize) -> bool {
        EntitySpan::hide(&mut self.entity_spans.borrow_mut(), start, end)
    }

    /// Starts a span of geometry that is not an entity (`PARTICLES`, `DESTROY`...).
    pub(super) fn mark_stage(&self, start: usize, stage: &str) {
        if self.pack_ids.is_some() || native_spans() {
            self.push_span(start, stage, 0);
        }
    }

    fn push_span(&self, start: usize, stage: &str, id: i32) {
        let mut spans = self.entity_spans.borrow_mut();
        let span = EntitySpan {
            start: start as u32,
            stage: horizon_shaders::render_stage(stage),
            id,
            ..Default::default()
        };
        // A span that drew nothing gives way to the next.
        match spans.last_mut() {
            Some(last) if last.start == span.start => *last = span,
            _ => spans.push(span),
        }
    }
}

/// Spans for a native mod (`native_render::RenderNeeds::entity_spans`), without a pack.
fn native_spans() -> bool {
    horizon_client::gfx::native_render::render_needs().entity_spans
}

/// A span's id for entity type `name` without a pack: stable, so a mod can match runs from one
/// frame to the next.
fn name_id(name: &str) -> i32 {
    // FNV-1a.
    let mut hash: u32 = 0x811c_9dc5;
    for byte in name.bytes() {
        hash = (hash ^ u32::from(byte)).wrapping_mul(0x0100_0193);
    }
    hash as i32
}

/// `mc_Entity` (x, y) of each block sprite layer, as (id, fluid) pairs: terrain vertices carry
/// their sprite layer, not their block. A layer takes the id of the block named like its sprite
/// (`block/oak_leaves` for `oak_leaves`), else the id most blocks drawing it share (ties: the
/// lowest); -1 when no block drawing it has one. y is 1 for the fluid sprites, -1 otherwise.
fn block_id_table(pack: &super::PackResources, ids: &BlockIds) -> Vec<i32> {
    use std::collections::{BTreeMap, BTreeSet};
    let layers = pack
        .render
        .sprite_layers
        .values()
        .max()
        .map_or(0, |l| l + 1) as usize;
    let mut table = vec![-1; layers * 2];
    if ids.is_empty() {
        return table;
    }
    let registry = pack.assets.registry;
    let catalog = &pack.render.model_catalog;
    let sprite = |name: &str| pack.render.sprite_layers.get(name).copied();
    // (layer, id) -> (a block named like the sprite, the blocks).
    let mut votes: BTreeMap<(u32, i32), (bool, BTreeSet<&str>)> = BTreeMap::new();
    let mut pair_counts: HashMap<(&str, i32), u8> = HashMap::new();
    for i in 0..registry.len() {
        let state_id = horizon_world::registry::BlockStateId(i as u32);
        let Some(state) = registry.state(state_id) else {
            continue;
        };
        if !ids.contains_block(&state.name) {
            continue;
        }
        let Some(id) = ids.id(&state.name, |k| state.properties.get(k).map(String::as_str)) else {
            continue;
        };
        let count = pair_counts.entry((state.name.as_str(), id)).or_insert(0);
        if *count >= 4 {
            continue;
        }
        *count += 1;
        let block = state.name.strip_prefix("minecraft:").unwrap_or(&state.name);
        let mut vote = |layer: u32| {
            let named = pack
                .layer_names
                .get(&layer)
                .and_then(|n| n.strip_prefix("block/"))
                == Some(block);
            let v = votes.entry((layer, id)).or_default();
            v.0 |= named;
            v.1.insert(&state.name);
        };
        // Fluids draw from their own sprites.
        let fluid = match block {
            "water" => ["water_still", "water_flow"],
            "lava" => ["lava_still", "lava_flow"],
            _ => ["", ""],
        };
        for f in fluid.iter().filter(|f| !f.is_empty()) {
            if let Some(l) = sprite(&format!("minecraft:block/{f}")) {
                vote(l);
            }
        }
        let origin = horizon_core::position::BlockPos::new(0, 0, 0);
        for (_, model) in catalog.collect(state_id, origin).unwrap_or_default() {
            for face in &model.faces {
                vote(face.layer);
            }
        }
    }
    let mut best: BTreeMap<u32, (bool, usize, i32)> = BTreeMap::new();
    for ((layer, id), (named, blocks)) in votes {
        let candidate = (named, blocks.len(), -id);
        let b = best.entry(layer).or_insert(candidate);
        if candidate > *b {
            *b = candidate;
        }
    }
    for (layer, (_, _, id)) in best {
        if let Some(slot) = table.get_mut(layer as usize * 2) {
            *slot = -id;
        }
    }
    for f in ["water_still", "water_flow", "lava_still", "lava_flow"] {
        if let Some(l) = sprite(&format!("minecraft:block/{f}"))
            && let Some(slot) = table.get_mut(l as usize * 2 + 1)
        {
            *slot = 1;
        }
    }
    table
}

#[cfg(test)]
mod native_pack_tests {
    use super::active_pack;
    use horizon_client::mod_list::{Installed, ModList, NativePage};

    #[test]
    fn native_shader_follows_its_mod_without_affecting_other_packs() {
        let mut mods = ModList::default();
        mods.installed.push(Installed {
            id: "horizon_better_visuals".into(),
            title: "Better Visuals".into(),
            description: String::new(),
            problem: None,
            dev: false,
            native: Some(NativePage::default()),
        });
        let owned = "native-horizon_better_visuals";
        assert_eq!(active_pack(owned, &mods), owned);
        mods.disabled.insert("horizon_better_visuals".into());
        assert_eq!(active_pack(owned, &mods), "");
        assert_eq!(active_pack("golden_hour", &mods), "golden_hour");
        mods.installed[0].native = None;
        assert_eq!(active_pack(owned, &mods), owned);
    }
}
