//! Platform hooks the touch/mobile code needs from the windowing layer.
//!
//! Android gets them from Horizon's patched winit (`winit::platform::android::native_*`);
//! iOS has no equivalent, so it answers with the plain-touchscreen defaults: one touch
//! device, never a gamepad or mouse, and a content rect that fills the surface. Safe-area
//! insets on iOS are applied by `horizon-ios` through the HUD margins, not here.
use winit::event::DeviceId;

/// Android's native device id (> 0 for an attached gamepad). iOS: 0, never a gamepad.
#[cfg(target_os = "android")]
pub fn device_id(id: DeviceId) -> i32 {
    winit::platform::android::native_device_id(id)
}
#[cfg(not(target_os = "android"))]
pub fn device_id(_id: DeviceId) -> i32 {
    0
}

/// True when the event came from a mouse/trackpad rather than a finger.
#[cfg(target_os = "android")]
pub fn pointer_device(id: DeviceId) -> bool {
    winit::platform::android::native_pointer_device(id)
}
#[cfg(not(target_os = "android"))]
pub fn pointer_device(_id: DeviceId) -> bool {
    false
}

/// The `[x, y, width, height]` of the game inside a surface of `size`.
#[cfg(target_os = "android")]
pub fn content_rect(size: [u32; 2]) -> [u32; 4] {
    winit::platform::android::native_content_rect(size)
}
#[cfg(not(target_os = "android"))]
pub fn content_rect(size: [u32; 2]) -> [u32; 4] {
    [0, 0, size[0], size[1]]
}
