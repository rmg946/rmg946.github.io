//! Android's std file-lock API can be unsupported; use Bionic's advisory flock.
use std::{fs::File, io};

pub fn exclusive(file: &File) -> io::Result<()> {
    #[cfg(not(any(any(target_os = "android", target_os = "ios"), target_os = "ios")))]
    {
        file.lock()
    }
    #[cfg(any(any(target_os = "android", target_os = "ios"), target_os = "ios"))]
    {
        loop {
            // The persistent inode is unlocked when File is dropped.
            match rustix::fs::flock(file, rustix::fs::FlockOperation::LockExclusive) {
                Ok(()) => return Ok(()),
                Err(rustix::io::Errno::INTR) => {}
                Err(error) => return Err(error.into()),
            }
        }
    }
}
